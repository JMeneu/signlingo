class Conv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.Conv2d
  act : __torch__.torch.nn.modules.activation.SiLU
  def forward(self: __torch__.ultralytics.nn.modules.Conv,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    x: Tensor) -> Tensor:
    conv = self.conv
    _0 = (argument_1).forward((conv).forward(x, ), )
    return _0
class C2f(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.___torch_mangle_5.Conv
  cv2 : __torch__.ultralytics.nn.modules.___torch_mangle_8.Conv
  m : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.ultralytics.nn.modules.C2f,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    _0 = getattr(m, "0")
    cv1 = self.cv1
    _1 = (cv1).forward(argument_1, argument_2, )
    _2 = torch.split_with_sizes(_1, [16, 16], 1)
    _3, input, = _2
    _4 = [_3, input, (_0).forward(argument_1, input, )]
    input0 = torch.cat(_4, 1)
    return (cv2).forward(argument_1, input0, )
class Bottleneck(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.___torch_mangle_11.Conv
  cv2 : __torch__.ultralytics.nn.modules.___torch_mangle_14.Conv
  def forward(self: __torch__.ultralytics.nn.modules.Bottleneck,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    input: Tensor) -> Tensor:
    cv2 = self.cv2
    cv1 = self.cv1
    _5 = (cv2).forward(argument_1, (cv1).forward(argument_1, input, ), )
    return torch.add(input, _5)
class SPPF(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.___torch_mangle_85.Conv
  cv2 : __torch__.ultralytics.nn.modules.___torch_mangle_88.Conv
  m : __torch__.torch.nn.modules.pooling.MaxPool2d
  def forward(self: __torch__.ultralytics.nn.modules.SPPF,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _6 = (cv1).forward(argument_1, argument_2, )
    _7 = (m).forward(_6, )
    _8 = (m).forward1(_7, )
    input = torch.cat([_6, _7, _8, (m).forward2(_8, )], 1)
    return (cv2).forward(argument_1, input, )
class Concat(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.ultralytics.nn.modules.Concat,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    input = torch.cat([argument_1, argument_2], 1)
    return input
class Detect(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv2 : __torch__.torch.nn.modules.container.___torch_mangle_182.ModuleList
  cv3 : __torch__.torch.nn.modules.container.___torch_mangle_207.ModuleList
  dfl : __torch__.ultralytics.nn.modules.DFL
  def forward(self: __torch__.ultralytics.nn.modules.Detect,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor) -> Tensor:
    dfl = self.dfl
    cv3 = self.cv3
    _2 = getattr(cv3, "2")
    cv2 = self.cv2
    _20 = getattr(cv2, "2")
    cv30 = self.cv3
    _1 = getattr(cv30, "1")
    cv20 = self.cv2
    _10 = getattr(cv20, "1")
    cv31 = self.cv3
    _0 = getattr(cv31, "0")
    cv32 = self.cv3
    _21 = getattr(cv32, "2")
    _11 = getattr(_21, "1")
    act = _11.act
    cv21 = self.cv2
    _00 = getattr(cv21, "0")
    _9 = ops.prim.NumToTensor(torch.size(argument_1, 0))
    _3 = int(_9)
    _4 = int(_9)
    _12 = int(_9)
    _13 = [(_00).forward(act, argument_1, ), (_0).forward(act, argument_1, )]
    xi = torch.cat(_13, 1)
    _14 = [(_10).forward(act, argument_2, ), (_1).forward(act, argument_2, )]
    xi0 = torch.cat(_14, 1)
    _15 = [(_20).forward(act, argument_3, ), (_2).forward(argument_3, )]
    xi1 = torch.cat(_15, 1)
    _16 = [torch.view(xi, [_12, 90, -1]), torch.view(xi0, [_4, 90, -1]), torch.view(xi1, [_3, 90, -1])]
    _17 = torch.split_with_sizes(torch.cat(_16, 2), [64, 26], 1)
    x, cls, = _17
    _18 = (dfl).forward(x, )
    anchor_points = torch.unsqueeze(CONSTANTS.c0, 0)
    lt, rb, = torch.chunk(_18, 2, 1)
    x1y1 = torch.sub(anchor_points, lt)
    x2y2 = torch.add(anchor_points, rb)
    c_xy = torch.div(torch.add(x1y1, x2y2), CONSTANTS.c1)
    wh = torch.sub(x2y2, x1y1)
    dbox = torch.mul(torch.cat([c_xy, wh], 1), CONSTANTS.c2)
    _19 = torch.cat([dbox, torch.sigmoid(cls)], 1)
    return _19
class DFL(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_208.Conv2d
  def forward(self: __torch__.ultralytics.nn.modules.DFL,
    x: Tensor) -> Tensor:
    conv = self.conv
    b = ops.prim.NumToTensor(torch.size(x, 0))
    _20 = int(b)
    _21 = int(b)
    a = ops.prim.NumToTensor(torch.size(x, 2))
    _22 = int(a)
    _23 = torch.transpose(torch.view(x, [_21, 4, 16, int(a)]), 2, 1)
    input = torch.softmax(_23, 1)
    distance = torch.view((conv).forward(input, ), [_20, 4, _22])
    return distance
